# ✦ CodeAI — Editor Inteligente

Editor de código com IA integrada (Gemini). Cole qualquer HTML e peça modificações em linguagem natural.

---

## 🚀 Como rodar localmente

### 1. Instale as dependências
```bash
npm install
```

### 2. Configure sua API Key
Abra o arquivo `.env` e coloque sua chave do Gemini:
```
GEMINI_API_KEY=sua_chave_aqui
```
> Pegue sua chave em: https://aistudio.google.com

### 3. Rode o servidor
```bash
npm start
```

### 4. Acesse no navegador
```
http://localhost:3000
```

---

## ☁️ Como hospedar no Railway (grátis)

1. Suba o projeto para o GitHub
2. Acesse https://railway.app e faça login com GitHub
3. Clique em **"New Project" → "Deploy from GitHub"**
4. Selecione o repositório
5. Vá em **Variables** e adicione:
   - `GEMINI_API_KEY` = sua chave do Gemini
6. Pronto! O Railway gera uma URL pública automaticamente

---

## ☁️ Como hospedar no Render (grátis)

1. Suba o projeto para o GitHub
2. Acesse https://render.com e faça login
3. Clique em **"New Web Service"**
4. Conecte o repositório do GitHub
5. Configure:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
6. Em **Environment Variables** adicione:
   - `GEMINI_API_KEY` = sua chave do Gemini
7. Clique em **Deploy** e aguarde

---

## 📁 Estrutura do projeto

```
codeai/
├── server.js          ← Servidor Node.js (chama a API do Gemini)
├── package.json       ← Dependências
├── .env               ← Sua API Key (não sobe pro GitHub!)
├── .gitignore         ← Ignora node_modules e .env
└── public/
    └── index.html     ← Interface do editor
```

---

## 💡 Como usar

1. Cole qualquer código HTML no editor à esquerda
2. O preview aparece instantaneamente à direita
3. Digite no chat o que quer mudar: *"deixa o botão verde"*, *"adiciona animação"*, *"muda a fonte"*
4. A IA modifica o código e o preview atualiza automaticamente
